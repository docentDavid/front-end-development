var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/2fc4c_next_deff92b3._.js")
R.c("server/chunks/[root-of-the-server]__8e352abd._.js")
R.m("[project]/Downloads/front-end-development-week-2/week-2-finished/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/Downloads/front-end-development-week-2/week-2-finished/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Downloads/front-end-development-week-2/week-2-finished/app/favicon--route-entry.js [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript)")
module.exports=R.m("[project]/Downloads/front-end-development-week-2/week-2-finished/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Downloads/front-end-development-week-2/week-2-finished/app/favicon--route-entry.js [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript)").exports
