module.exports = [
"[project]/Downloads/front-end-development-week-2/week-2-finished/app/favicon.ico (static in ecmascript)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.5c673f2e.ico");}),
"[project]/Downloads/front-end-development-week-2/week-2-finished/app/favicon.ico.mjs { IMAGE => \"[project]/Downloads/front-end-development-week-2/week-2-finished/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/front-end-development-week-2/week-2-finished/app/favicon.ico (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__["default"],
    width: 48,
    height: 48
};
}),
];

//# sourceMappingURL=Downloads_front-end-development-week-2_week-2-finished_app_c34d6f3e._.js.map