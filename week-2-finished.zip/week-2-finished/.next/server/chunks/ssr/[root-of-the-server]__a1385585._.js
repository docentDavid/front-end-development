module.exports = [
"[project]/Downloads/front-end-development-week-2/week-2-finished/.next-internal/server/app/products/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/Downloads/front-end-development-week-2/week-2-finished/app/favicon.ico.mjs { IMAGE => \"[project]/Downloads/front-end-development-week-2/week-2-finished/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Downloads/front-end-development-week-2/week-2-finished/app/favicon.ico.mjs { IMAGE => \"[project]/Downloads/front-end-development-week-2/week-2-finished/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/Downloads/front-end-development-week-2/week-2-finished/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Downloads/front-end-development-week-2/week-2-finished/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/Downloads/front-end-development-week-2/week-2-finished/app/not-found.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Downloads/front-end-development-week-2/week-2-finished/app/not-found.tsx [app-rsc] (ecmascript)"));
}),
"[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProductDetailPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/front-end-development-week-2/week-2-finished/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/front-end-development-week-2/week-2-finished/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/front-end-development-week-2/week-2-finished/node_modules/next/dist/client/app-dir/link.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Downloads/front-end-development-week-2/week-2-finished/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/front-end-development-week-2/week-2-finished/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
;
;
;
;
async function ProductDetailPage({ params }) {
    const { id } = params;
    // Check if id is a valid number
    if (!id || isNaN(Number(id))) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    const res = await fetch(`https://fakestoreapi.com/products/${id}`);
    if (!res.ok) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    let product = null;
    try {
        const data = await res.json();
        // Some APIs return {} or null for not found, so check for id
        if (!data || typeof data !== "object" || !("id" in data)) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
        }
        product = data;
    } catch (e) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "relative overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "aria-hidden": "true",
                className: "pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-indigo-50 to-white"
            }, void 0, false, {
                fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: "mb-8",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-3xl font-extrabold",
                            children: "Product Details"
                        }, void 0, false, {
                            fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-2xl font-bold pb-4",
                                children: product.title
                            }, void 0, false, {
                                fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                                lineNumber: 46,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: product.description
                            }, void 0, false, {
                                fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                                lineNumber: 47,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-lg font-bold py-4",
                                children: [
                                    "€ ",
                                    product.price
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                                lineNumber: 48,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                src: product.image,
                                alt: product.title,
                                width: 300,
                                height: 300
                            }, void 0, false, {
                                fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                                lineNumber: 49,
                                columnNumber: 11
                            }, this)
                        ]
                    }, product.id, true, {
                        fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "cursor-pointer text-center pt-4 text-indigo-600",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$front$2d$end$2d$development$2d$week$2d$2$2f$week$2d$2$2d$finished$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                            href: "/products",
                            children: "Back to all products"
                        }, void 0, false, {
                            fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                            lineNumber: 58,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
}),
"[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Downloads/front-end-development-week-2/week-2-finished/app/products/[id]/page.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__a1385585._.js.map