var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/e0f4c_ae2ad7c8._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/Downloads/front-end-development-week-2/week-2-starter/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/Downloads/front-end-development-week-2/week-2-starter/node_modules/next/document.js [ssr] (ecmascript)").exports
