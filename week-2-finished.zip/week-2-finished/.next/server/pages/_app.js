var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__6b395152._.js")
R.m("[project]/Downloads/front-end-development-week-2/week-2-starter/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/Downloads/front-end-development-week-2/week-2-starter/node_modules/next/app.js [ssr] (ecmascript)").exports
