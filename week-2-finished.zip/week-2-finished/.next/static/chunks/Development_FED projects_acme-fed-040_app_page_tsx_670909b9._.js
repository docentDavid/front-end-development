(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/853c1_next_dist_32215200._.js",
  "static/chunks/[next]_internal_font_google_2d2d3afd._.css"
],
    source: "dynamic"
});
