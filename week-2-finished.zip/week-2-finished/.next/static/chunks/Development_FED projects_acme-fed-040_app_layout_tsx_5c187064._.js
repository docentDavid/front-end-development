(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__7ae0ac90._.css",
  "static/chunks/853c1_next_dist_1b90d704._.js"
],
    source: "dynamic"
});
