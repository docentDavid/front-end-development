(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/e0f4c_next_dist_compiled_next-devtools_index_e7b889b4.js",
  "static/chunks/e0f4c_next_dist_compiled_dfd2cd3c._.js",
  "static/chunks/e0f4c_next_dist_shared_lib_dac6891d._.js",
  "static/chunks/e0f4c_next_dist_client_6098f4b7._.js",
  "static/chunks/e0f4c_next_dist_d00e81ee._.js",
  "static/chunks/e0f4c_next_app_1e1e1e2e.js",
  "static/chunks/[next]_entry_page-loader_ts_89612cde._.js",
  "static/chunks/e0f4c_react-dom_dc0a6420._.js",
  "static/chunks/e0f4c_ec898e18._.js",
  "static/chunks/[root-of-the-server]__af0764d2._.js"
],
    source: "entry"
});
