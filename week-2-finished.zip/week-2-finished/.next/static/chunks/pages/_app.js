__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e0f4c_next_dist_compiled_next-devtools_index_e7b889b4.js",
  "static/chunks/e0f4c_next_dist_compiled_dfd2cd3c._.js",
  "static/chunks/e0f4c_next_dist_shared_lib_dac6891d._.js",
  "static/chunks/e0f4c_next_dist_client_6098f4b7._.js",
  "static/chunks/e0f4c_next_dist_d00e81ee._.js",
  "static/chunks/e0f4c_next_app_1e1e1e2e.js",
  "static/chunks/[next]_entry_page-loader_ts_89612cde._.js",
  "static/chunks/e0f4c_react-dom_dc0a6420._.js",
  "static/chunks/e0f4c_ec898e18._.js",
  "static/chunks/[root-of-the-server]__af0764d2._.js",
  "static/chunks/Downloads_front-end-development-week-2_week-2-starter_pages__app_2da965e7._.js",
  "static/chunks/63a6e_front-end-development-week-2_week-2-starter_pages__app_3c1b815f._.js"
])
