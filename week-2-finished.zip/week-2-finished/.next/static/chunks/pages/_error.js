__turbopack_load_page_chunks__("/_error", [
  "static/chunks/e0f4c_next_dist_compiled_next-devtools_index_e7b889b4.js",
  "static/chunks/e0f4c_next_dist_compiled_dfd2cd3c._.js",
  "static/chunks/e0f4c_next_dist_shared_lib_6d178e54._.js",
  "static/chunks/e0f4c_next_dist_client_6098f4b7._.js",
  "static/chunks/e0f4c_next_dist_144600ba._.js",
  "static/chunks/e0f4c_next_error_fad185ab.js",
  "static/chunks/[next]_entry_page-loader_ts_f0fb736c._.js",
  "static/chunks/e0f4c_react-dom_dc0a6420._.js",
  "static/chunks/e0f4c_ec898e18._.js",
  "static/chunks/[root-of-the-server]__f00556c2._.js",
  "static/chunks/Downloads_front-end-development-week-2_week-2-starter_pages__error_2da965e7._.js",
  "static/chunks/63a6e_front-end-development-week-2_week-2-starter_pages__error_310bbc91._.js"
])
