(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__26d75abd._.css",
  "static/chunks/2fc4c_next_dist_7f9aedee._.js"
],
    source: "dynamic"
});
