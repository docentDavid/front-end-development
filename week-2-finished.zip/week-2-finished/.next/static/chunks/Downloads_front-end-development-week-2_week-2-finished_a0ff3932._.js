(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b0b78939._.js",
  "static/chunks/2fc4c_next_dist_compiled_react-dom_f98c162e._.js",
  "static/chunks/2fc4c_next_dist_compiled_next-devtools_index_125485b2.js",
  "static/chunks/2fc4c_next_dist_compiled_bd118153._.js",
  "static/chunks/2fc4c_next_dist_client_a8da647d._.js",
  "static/chunks/2fc4c_next_dist_86e58da2._.js",
  "static/chunks/2fc4c_@swc_helpers_cjs_f9e68697._.js"
],
    source: "entry"
});
