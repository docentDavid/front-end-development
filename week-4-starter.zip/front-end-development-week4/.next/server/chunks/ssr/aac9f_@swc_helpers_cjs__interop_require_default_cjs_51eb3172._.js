module.exports = [
"[project]/Downloads/front-end-development-week3-main/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
exports._ = _interop_require_default;
}),
];

//# sourceMappingURL=aac9f_%40swc_helpers_cjs__interop_require_default_cjs_51eb3172._.js.map