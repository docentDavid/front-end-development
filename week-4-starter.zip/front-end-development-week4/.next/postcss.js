var R=require("./build/chunks/[turbopack]_runtime.js")("postcss.js")
R.c("build/chunks/[turbopack-node]_transforms_postcss_ts_d2a61112._.js")
R.c("build/chunks/[root-of-the-server]__78cd848c._.js")
R.m("[turbopack-node]/globals.ts [postcss] (ecmascript)")
R.m("[turbopack-node]/ipc/evaluate.ts/evaluate.js { INNER => \"[turbopack-node]/transforms/postcss.ts { CONFIG => \\\"[project]/Downloads/front-end-development-week3-main/postcss.config.mjs [postcss] (ecmascript)\\\" } [postcss] (ecmascript)\", RUNTIME => \"[turbopack-node]/ipc/evaluate.ts [postcss] (ecmascript)\" } [postcss] (ecmascript)")
module.exports=R.m("[turbopack-node]/ipc/evaluate.ts/evaluate.js { INNER => \"[turbopack-node]/transforms/postcss.ts { CONFIG => \\\"[project]/Downloads/front-end-development-week3-main/postcss.config.mjs [postcss] (ecmascript)\\\" } [postcss] (ecmascript)\", RUNTIME => \"[turbopack-node]/ipc/evaluate.ts [postcss] (ecmascript)\" } [postcss] (ecmascript)").exports
