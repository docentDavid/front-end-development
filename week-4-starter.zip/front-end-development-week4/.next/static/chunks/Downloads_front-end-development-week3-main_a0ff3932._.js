(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_54eddaf7._.js",
  "static/chunks/aac9f_next_dist_compiled_react-dom_0836158b._.js",
  "static/chunks/aac9f_next_dist_compiled_next-devtools_index_35ac4413.js",
  "static/chunks/aac9f_next_dist_compiled_176f9085._.js",
  "static/chunks/aac9f_next_dist_client_06a7a63c._.js",
  "static/chunks/aac9f_next_dist_e1b61359._.js",
  "static/chunks/aac9f_@swc_helpers_cjs_cae5123b._.js"
],
    source: "entry"
});
