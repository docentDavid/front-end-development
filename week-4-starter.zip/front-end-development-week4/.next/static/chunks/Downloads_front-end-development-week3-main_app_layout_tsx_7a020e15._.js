(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__c2fc6fc1._.css",
  "static/chunks/aac9f_next_dist_65488b93._.js"
],
    source: "dynamic"
});
