(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d73d8f61._.js",
  "static/chunks/f5e63_next_dist_compiled_react-dom_b8c508f8._.js",
  "static/chunks/f5e63_next_dist_compiled_next-devtools_index_bef315d0.js",
  "static/chunks/f5e63_next_dist_compiled_128ebfae._.js",
  "static/chunks/f5e63_next_dist_client_d1e4c942._.js",
  "static/chunks/f5e63_next_dist_2f91f19a._.js",
  "static/chunks/f5e63_@swc_helpers_cjs_dd016996._.js"
],
    source: "entry"
});
