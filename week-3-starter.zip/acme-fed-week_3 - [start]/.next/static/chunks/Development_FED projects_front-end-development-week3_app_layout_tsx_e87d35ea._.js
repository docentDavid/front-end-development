(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__723a05b3._.css",
  "static/chunks/f5e63_next_dist_297f4693._.js"
],
    source: "dynamic"
});
