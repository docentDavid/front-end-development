globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/f5e63_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d73d8f61._.js",
    "static/chunks/f5e63_next_dist_compiled_react-dom_b8c508f8._.js",
    "static/chunks/f5e63_next_dist_compiled_next-devtools_index_bef315d0.js",
    "static/chunks/f5e63_next_dist_compiled_128ebfae._.js",
    "static/chunks/f5e63_next_dist_client_d1e4c942._.js",
    "static/chunks/f5e63_next_dist_2f91f19a._.js",
    "static/chunks/f5e63_@swc_helpers_cjs_dd016996._.js",
    "static/chunks/Development_FED projects_front-end-development-week3_a0ff3932._.js",
    "static/chunks/turbopack-Development_FED projects_front-end-development-week3_b2d25345._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];