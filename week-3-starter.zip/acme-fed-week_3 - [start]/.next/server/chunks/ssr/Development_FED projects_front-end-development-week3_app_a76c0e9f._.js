module.exports = [
"[project]/Development/FED projects/front-end-development-week3/app/favicon.ico (static in ecmascript)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.5c673f2e.ico");}),
"[project]/Development/FED projects/front-end-development-week3/app/favicon.ico.mjs { IMAGE => \"[project]/Development/FED projects/front-end-development-week3/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$front$2d$end$2d$development$2d$week3$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/Development/FED projects/front-end-development-week3/app/favicon.ico (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$front$2d$end$2d$development$2d$week3$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__["default"],
    width: 48,
    height: 48
};
}),
];

//# sourceMappingURL=Development_FED%20projects_front-end-development-week3_app_a76c0e9f._.js.map