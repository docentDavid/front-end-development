module.exports = [
"[project]/Development/FED projects/acme-nextjs/app/favicon.ico (static in ecmascript)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.5c673f2e.ico");}),
"[project]/Development/FED projects/acme-nextjs/app/favicon.ico.mjs { IMAGE => \"[project]/Development/FED projects/acme-nextjs/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$nextjs$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/Development/FED projects/acme-nextjs/app/favicon.ico (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$nextjs$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__["default"],
    width: 48,
    height: 48
};
}),
];

//# sourceMappingURL=Development_FED%20projects_acme-nextjs_app_afb98ea8._.js.map