globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/2e32f_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_23b3871a._.js",
    "static/chunks/2e32f_next_dist_compiled_react-dom_d6b5b05e._.js",
    "static/chunks/2e32f_next_dist_compiled_next-devtools_index_70265650.js",
    "static/chunks/2e32f_next_dist_compiled_3e51afd2._.js",
    "static/chunks/2e32f_next_dist_client_43550736._.js",
    "static/chunks/2e32f_next_dist_7a129bf2._.js",
    "static/chunks/2e32f_@swc_helpers_cjs_96c79048._.js",
    "static/chunks/Development_FED projects_acme-fed-week_1 - [final]_a0ff3932._.js",
    "static/chunks/turbopack-Development_FED projects_acme-fed-week_1 - [final]_25fb09b7._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];