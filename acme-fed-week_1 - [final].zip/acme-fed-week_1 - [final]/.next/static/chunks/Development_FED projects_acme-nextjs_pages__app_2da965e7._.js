(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/9bb8e_next_dist_compiled_next-devtools_index_58cef098.js",
  "static/chunks/9bb8e_next_dist_compiled_b2ad67d9._.js",
  "static/chunks/9bb8e_next_dist_shared_lib_a8f9ed17._.js",
  "static/chunks/9bb8e_next_dist_client_b1698e60._.js",
  "static/chunks/9bb8e_next_dist_0d090116._.js",
  "static/chunks/9bb8e_next_app_a7fc6c0e.js",
  "static/chunks/[next]_entry_page-loader_ts_abbfe9fd._.js",
  "static/chunks/9bb8e_react-dom_8dbe65fb._.js",
  "static/chunks/9bb8e_0ff4bf81._.js",
  "static/chunks/[root-of-the-server]__2462e5c9._.js"
],
    source: "entry"
});
