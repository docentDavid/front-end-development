__turbopack_load_page_chunks__("/_error", [
  "static/chunks/9bb8e_next_dist_compiled_next-devtools_index_58cef098.js",
  "static/chunks/9bb8e_next_dist_compiled_b2ad67d9._.js",
  "static/chunks/9bb8e_next_dist_shared_lib_30443bc6._.js",
  "static/chunks/9bb8e_next_dist_client_b1698e60._.js",
  "static/chunks/9bb8e_next_dist_852a5952._.js",
  "static/chunks/9bb8e_next_error_6f67fe1d.js",
  "static/chunks/[next]_entry_page-loader_ts_a12298f8._.js",
  "static/chunks/9bb8e_react-dom_8dbe65fb._.js",
  "static/chunks/9bb8e_0ff4bf81._.js",
  "static/chunks/[root-of-the-server]__8a525d8d._.js",
  "static/chunks/Development_FED projects_acme-nextjs_pages__error_2da965e7._.js",
  "static/chunks/turbopack-Development_FED projects_acme-nextjs_pages__error_7b5f868e._.js"
])
