(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__6d155aec._.css",
  "static/chunks/2e32f_next_dist_07dec302._.js"
],
    source: "dynamic"
});
