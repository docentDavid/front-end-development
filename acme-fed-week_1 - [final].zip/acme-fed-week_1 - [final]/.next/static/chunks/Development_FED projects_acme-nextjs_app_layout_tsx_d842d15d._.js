(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__71e801c2._.css",
  "static/chunks/9bb8e_next_dist_f11a2164._.js"
],
    source: "dynamic"
});
