(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_a1ed6d28._.js",
  "static/chunks/9bb8e_next_dist_compiled_react-dom_00839eda._.js",
  "static/chunks/9bb8e_next_dist_compiled_next-devtools_index_0088913f.js",
  "static/chunks/9bb8e_next_dist_compiled_e8e2812c._.js",
  "static/chunks/9bb8e_next_dist_client_64fcddd8._.js",
  "static/chunks/9bb8e_next_dist_24e107ea._.js",
  "static/chunks/9bb8e_@swc_helpers_cjs_cb768648._.js"
],
    source: "entry"
});
