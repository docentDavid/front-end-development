(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_23b3871a._.js",
  "static/chunks/2e32f_next_dist_compiled_react-dom_d6b5b05e._.js",
  "static/chunks/2e32f_next_dist_compiled_next-devtools_index_70265650.js",
  "static/chunks/2e32f_next_dist_compiled_3e51afd2._.js",
  "static/chunks/2e32f_next_dist_client_43550736._.js",
  "static/chunks/2e32f_next_dist_7a129bf2._.js",
  "static/chunks/2e32f_@swc_helpers_cjs_96c79048._.js"
],
    source: "entry"
});
