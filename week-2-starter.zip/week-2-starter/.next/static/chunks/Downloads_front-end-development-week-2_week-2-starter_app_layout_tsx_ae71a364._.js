(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__ca642aa0._.css",
  "static/chunks/e0f4c_next_dist_69a354ea._.js"
],
    source: "dynamic"
});
