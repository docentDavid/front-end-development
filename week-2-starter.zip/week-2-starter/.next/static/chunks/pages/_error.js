__turbopack_load_page_chunks__("/_error", [
  "static/chunks/8d2a3_next_dist_compiled_next-devtools_index_3309dddb.js",
  "static/chunks/8d2a3_next_dist_compiled_f235ca3e._.js",
  "static/chunks/8d2a3_next_dist_shared_lib_88b49de7._.js",
  "static/chunks/8d2a3_next_dist_client_86d31928._.js",
  "static/chunks/8d2a3_next_dist_06e23a4f._.js",
  "static/chunks/8d2a3_next_error_40c9a0f0.js",
  "static/chunks/[next]_entry_page-loader_ts_217fa3cc._.js",
  "static/chunks/8d2a3_react-dom_1f0825b0._.js",
  "static/chunks/8d2a3_cf1be34e._.js",
  "static/chunks/[root-of-the-server]__f822136b._.js",
  "static/chunks/Development_FED projects_acme-fed-week_2 - [start]_pages__error_2da965e7._.js",
  "static/chunks/81ae9_FED projects_acme-fed-week_2 - [start]_pages__error_43e0c394._.js"
])
