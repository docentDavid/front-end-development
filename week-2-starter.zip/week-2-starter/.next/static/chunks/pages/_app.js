__turbopack_load_page_chunks__("/_app", [
  "static/chunks/8d2a3_next_dist_compiled_next-devtools_index_3309dddb.js",
  "static/chunks/8d2a3_next_dist_compiled_f235ca3e._.js",
  "static/chunks/8d2a3_next_dist_shared_lib_258d06f0._.js",
  "static/chunks/8d2a3_next_dist_client_86d31928._.js",
  "static/chunks/8d2a3_next_dist_9d5f7d60._.js",
  "static/chunks/8d2a3_next_app_e90d377f.js",
  "static/chunks/[next]_entry_page-loader_ts_2c16b877._.js",
  "static/chunks/8d2a3_react-dom_1f0825b0._.js",
  "static/chunks/8d2a3_cf1be34e._.js",
  "static/chunks/[root-of-the-server]__42878ccf._.js",
  "static/chunks/Development_FED projects_acme-fed-week_2 - [start]_pages__app_2da965e7._.js",
  "static/chunks/turbopack-Development_FED projects_acme-fed-week_2 - [start]_pages__app_f7ca20bc._.js"
])
