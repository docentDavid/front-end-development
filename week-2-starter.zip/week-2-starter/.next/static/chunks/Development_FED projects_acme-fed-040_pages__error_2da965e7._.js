(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/853c1_next_dist_compiled_next-devtools_index_08901f3a.js",
  "static/chunks/853c1_next_dist_compiled_cc0be7b3._.js",
  "static/chunks/853c1_next_dist_shared_lib_eca8c20b._.js",
  "static/chunks/853c1_next_dist_client_95344f7e._.js",
  "static/chunks/853c1_next_dist_ca41b2c2._.js",
  "static/chunks/853c1_next_error_e9b21c50.js",
  "static/chunks/[next]_entry_page-loader_ts_36ad7cf6._.js",
  "static/chunks/853c1_react-dom_310de262._.js",
  "static/chunks/853c1_05a5406d._.js",
  "static/chunks/[root-of-the-server]__00286d2c._.js"
],
    source: "entry"
});
