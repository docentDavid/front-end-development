(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_13bd9d76._.js",
  "static/chunks/853c1_next_dist_compiled_react-dom_f75c0305._.js",
  "static/chunks/853c1_next_dist_compiled_next-devtools_index_84800170.js",
  "static/chunks/853c1_next_dist_compiled_220fa417._.js",
  "static/chunks/853c1_next_dist_client_50fcc19d._.js",
  "static/chunks/853c1_next_dist_6318f930._.js",
  "static/chunks/853c1_@swc_helpers_cjs_21eb4244._.js"
],
    source: "entry"
});
