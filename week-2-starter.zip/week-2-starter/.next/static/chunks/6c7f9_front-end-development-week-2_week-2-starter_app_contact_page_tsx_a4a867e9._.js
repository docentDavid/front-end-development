(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Downloads_front-end-development-week-2_week-2-starter_3fe76c63._.js"
],
    source: "dynamic"
});
