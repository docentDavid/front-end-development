(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_675ac1cc._.js",
  "static/chunks/e0f4c_next_dist_compiled_react-dom_c2fb18a9._.js",
  "static/chunks/e0f4c_next_dist_compiled_next-devtools_index_43d66fe0.js",
  "static/chunks/e0f4c_next_dist_compiled_a317790f._.js",
  "static/chunks/e0f4c_next_dist_client_28f5dbf5._.js",
  "static/chunks/e0f4c_next_dist_fba605fd._.js",
  "static/chunks/e0f4c_@swc_helpers_cjs_c33ba90c._.js"
],
    source: "entry"
});
