(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__eb2613c9._.css",
  "static/chunks/8d2a3_next_dist_55c86abb._.js"
],
    source: "dynamic"
});
