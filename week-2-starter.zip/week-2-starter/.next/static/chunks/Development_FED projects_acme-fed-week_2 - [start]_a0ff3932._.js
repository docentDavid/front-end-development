(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_ecf0dddf._.js",
  "static/chunks/8d2a3_next_dist_compiled_react-dom_12dd6bea._.js",
  "static/chunks/8d2a3_next_dist_compiled_next-devtools_index_b91e4f09.js",
  "static/chunks/8d2a3_next_dist_compiled_0d327bc2._.js",
  "static/chunks/8d2a3_next_dist_client_6f998d4b._.js",
  "static/chunks/8d2a3_next_dist_8aab3e6b._.js",
  "static/chunks/8d2a3_@swc_helpers_cjs_6f1e1029._.js"
],
    source: "entry"
});
