module.exports = [
"[project]/Development/FED projects/acme-fed-week_2 - [start]/app/favicon.ico (static in ecmascript)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.5c673f2e.ico");}),
"[project]/Development/FED projects/acme-fed-week_2 - [start]/app/favicon.ico.mjs { IMAGE => \"[project]/Development/FED projects/acme-fed-week_2 - [start]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/Development/FED projects/acme-fed-week_2 - [start]/app/favicon.ico (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__["default"],
    width: 48,
    height: 48
};
}),
];

//# sourceMappingURL=Development_FED%20projects_acme-fed-week_2%20-%20%5Bstart%5D_app_a1290227._.js.map