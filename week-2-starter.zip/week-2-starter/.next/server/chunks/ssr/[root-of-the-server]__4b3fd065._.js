module.exports = [
"[project]/Development/FED projects/acme-fed-week_2 - [start]/.next-internal/server/app/fake_store/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/Development/FED projects/acme-fed-week_2 - [start]/app/favicon.ico.mjs { IMAGE => \"[project]/Development/FED projects/acme-fed-week_2 - [start]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Development/FED projects/acme-fed-week_2 - [start]/app/favicon.ico.mjs { IMAGE => \"[project]/Development/FED projects/acme-fed-week_2 - [start]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/Development/FED projects/acme-fed-week_2 - [start]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Development/FED projects/acme-fed-week_2 - [start]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/Development/FED projects/acme-fed-week_2 - [start]/app/not-found.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Development/FED projects/acme-fed-week_2 - [start]/app/not-found.tsx [app-rsc] (ecmascript)"));
}),
"[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FakeStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Development/FED projects/acme-fed-week_2 - [start]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
async function FakeStore() {
    const products = await fetch("https://fakestoreapi.com/products").then((response)=>response.json());
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto px-4 py-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-2xl font-bold mb-4",
                children: "Fake Store - Products"
            }, void 0, false, {
                fileName: "[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx",
                lineNumber: 8,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold mb-2",
                children: "Raw Data:"
            }, void 0, false, {
                fileName: "[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx",
                lineNumber: 10,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                className: "bg-gray-100 p-4 rounded overflow-auto text-sm",
                children: JSON.stringify(products, null, 2)
            }, void 0, false, {
                fileName: "[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold mb-2 mt-8",
                children: "Formatted Products:"
            }, void 0, false, {
                fileName: "[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            products.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            children: product.title
                        }, void 0, false, {
                            fileName: "[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: product.description
                        }, void 0, false, {
                            fileName: "[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx",
                            lineNumber: 19,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                "Price: $",
                                product.price
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx",
                            lineNumber: 20,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Development$2f$FED__projects$2f$acme$2d$fed$2d$week_2__$2d$__$5b$start$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                            className: "mt-4"
                        }, void 0, false, {
                            fileName: "[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx",
                            lineNumber: 21,
                            columnNumber: 11
                        }, this)
                    ]
                }, product.id, true, {
                    fileName: "[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this))
        ]
    }, void 0, true, {
        fileName: "[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
}),
"[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Development/FED projects/acme-fed-week_2 - [start]/app/fake_store/page.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__4b3fd065._.js.map