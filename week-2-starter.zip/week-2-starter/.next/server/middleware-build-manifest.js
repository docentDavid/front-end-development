globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/8d2a3_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_ecf0dddf._.js",
    "static/chunks/8d2a3_next_dist_compiled_react-dom_12dd6bea._.js",
    "static/chunks/8d2a3_next_dist_compiled_next-devtools_index_b91e4f09.js",
    "static/chunks/8d2a3_next_dist_compiled_0d327bc2._.js",
    "static/chunks/8d2a3_next_dist_client_6f998d4b._.js",
    "static/chunks/8d2a3_next_dist_8aab3e6b._.js",
    "static/chunks/8d2a3_@swc_helpers_cjs_6f1e1029._.js",
    "static/chunks/Development_FED projects_acme-fed-week_2 - [start]_a0ff3932._.js",
    "static/chunks/turbopack-Development_FED projects_acme-fed-week_2 - [start]_f40b5afe._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];