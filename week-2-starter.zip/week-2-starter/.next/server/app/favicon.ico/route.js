var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/e0f4c_next_67367a34._.js")
R.c("server/chunks/[root-of-the-server]__bf0a5faa._.js")
R.m("[project]/Downloads/front-end-development-week-2/week-2-starter/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/Downloads/front-end-development-week-2/week-2-starter/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Downloads/front-end-development-week-2/week-2-starter/app/favicon--route-entry.js [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript)")
module.exports=R.m("[project]/Downloads/front-end-development-week-2/week-2-starter/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Downloads/front-end-development-week-2/week-2-starter/app/favicon--route-entry.js [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript)").exports
