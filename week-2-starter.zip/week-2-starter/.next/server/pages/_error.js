var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/8d2a3_e7ae71f4._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/8d2a3_next_51a9afeb._.js")
R.c("server/chunks/ssr/8d2a3_5c1542dd._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.m("[project]/Development/FED projects/acme-fed-week_2 - [start]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Development/FED projects/acme-fed-week_2 - [start]/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Development/FED projects/acme-fed-week_2 - [start]/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Development/FED projects/acme-fed-week_2 - [start]/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/Development/FED projects/acme-fed-week_2 - [start]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Development/FED projects/acme-fed-week_2 - [start]/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Development/FED projects/acme-fed-week_2 - [start]/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Development/FED projects/acme-fed-week_2 - [start]/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
